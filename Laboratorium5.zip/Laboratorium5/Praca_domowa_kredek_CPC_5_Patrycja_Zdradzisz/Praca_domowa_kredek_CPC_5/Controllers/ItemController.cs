﻿using Microsoft.AspNetCore.Mvc;
using Praca_domowa_kredek_CPC_5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Controllers
{
    public class ItemController : Controller
    {
        private readonly BorrowedContext _db;

        public ItemController(BorrowedContext db)
        {
            _db = db;
        }

        //wyświetlenie tablicy
        public IActionResult Index()
        {
            IEnumerable<Item> objList = _db.Item;
            return View(objList);
        }

        //GET Create
        public IActionResult Create()
        {

            return View();
        }

        //POST Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Item obj)
        {
            _db.Item.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

       //POST Edit
        [HttpPost]
        public IActionResult Edit(int id)
        {
            var obj = _db.Item.Find(id);
            return View(obj);
        }

        //GET Edit
        public IActionResult Edit(Item obj)
        {
            _db.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        
        //GET Delete
        public IActionResult Delete(int id)
        {

            var obj = _db.Item.Find(id);
            _db.Item.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}

