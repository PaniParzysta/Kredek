﻿using Microsoft.AspNetCore.Mvc;
using Praca_domowa_kredek_CPC_5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Controllers
{
    
    public class ToPayController : Controller
    {
        private readonly BorrowedContext _db;

        public ToPayController(BorrowedContext db)
        {
            _db = db;
        }

        //wyświetlenie tablicy
        public IActionResult Index()
        {
            IEnumerable<ToPay> objList = _db.ToPays;
            return View(objList);
        }
    }
}
