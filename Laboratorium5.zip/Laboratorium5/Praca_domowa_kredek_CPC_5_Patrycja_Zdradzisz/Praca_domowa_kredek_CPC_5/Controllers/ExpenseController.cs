﻿using Microsoft.AspNetCore.Mvc;
using Praca_domowa_kredek_CPC_5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Controllers
{
    public class ExpenseController : Controller
    {
        private readonly BorrowedContext _db;

        public ExpenseController(BorrowedContext db)
        {
            _db = db;
        }

        //wyświetlenie tablicy
        public IActionResult Index()
        {
            IEnumerable<Expense> objList = _db.Expenses;
            return View(objList);
        }
    }
}
