﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Praca_domowa_kredek_CPC_5.Migrations
{
    public partial class Second : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "BorrowedItem",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ItemName",
                table: "BorrowedItem",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ItemNumber",
                table: "BorrowedItem",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "BorrowedItem",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "BorrowedItem");

            migrationBuilder.DropColumn(
                name: "ItemName",
                table: "BorrowedItem");

            migrationBuilder.DropColumn(
                name: "ItemNumber",
                table: "BorrowedItem");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "BorrowedItem");
        }
    }
}
