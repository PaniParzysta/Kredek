﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Praca_domowa_kredek_CPC_5.Migrations
{
    public partial class _4th : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ToPays_Expenses_ExpenseForeignKey",
                table: "ToPays");

            migrationBuilder.DropIndex(
                name: "IX_ToPays_ExpenseForeignKey",
                table: "ToPays");

            migrationBuilder.DropColumn(
                name: "ExpenseForeignKey",
                table: "ToPays");

            migrationBuilder.CreateIndex(
                name: "IX_ToPays_ExpenseId",
                table: "ToPays",
                column: "ExpenseId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ToPays_Expenses_ExpenseId",
                table: "ToPays",
                column: "ExpenseId",
                principalTable: "Expenses",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ToPays_Expenses_ExpenseId",
                table: "ToPays");

            migrationBuilder.DropIndex(
                name: "IX_ToPays_ExpenseId",
                table: "ToPays");

            migrationBuilder.AddColumn<int>(
                name: "ExpenseForeignKey",
                table: "ToPays",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_ToPays_ExpenseForeignKey",
                table: "ToPays",
                column: "ExpenseForeignKey",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ToPays_Expenses_ExpenseForeignKey",
                table: "ToPays",
                column: "ExpenseForeignKey",
                principalTable: "Expenses",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
