﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Praca_domowa_kredek_CPC_5.Migrations
{
    public partial class Third : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "BorrowedItem");

            migrationBuilder.DropColumn(
                name: "ItemName",
                table: "BorrowedItem");

            migrationBuilder.DropColumn(
                name: "ItemNumber",
                table: "BorrowedItem");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "BorrowedItem");

            migrationBuilder.CreateTable(
                name: "Expenses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ExpenseName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Amount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Expenses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ToPays",
                columns: table => new
                {
                    PayId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ExpenseId = table.Column<int>(type: "int", nullable: false),
                    ExpenseForeignKey = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ToPays", x => x.PayId);
                    table.ForeignKey(
                        name: "FK_ToPays_Expenses_ExpenseForeignKey",
                        column: x => x.ExpenseForeignKey,
                        principalTable: "Expenses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ToPays_ExpenseForeignKey",
                table: "ToPays",
                column: "ExpenseForeignKey",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ToPays");

            migrationBuilder.DropTable(
                name: "Expenses");

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "BorrowedItem",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ItemName",
                table: "BorrowedItem",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ItemNumber",
                table: "BorrowedItem",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "BorrowedItem",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
