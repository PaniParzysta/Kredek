﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Models
{
    public class Item
    {
        [Key]
        public int ItemId { get; set; }
        //nazwa przedmiotu
        public string ItemName { get; set; }
        //liczba wypożyczonych przedmiotow tego typu
        public int ItemNumber { get; set; }

        //many-many relacja
        public virtual ICollection<BorrowedItem> BorrowedItems { get; set; }
    }
}
