﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Models
{
    public class FriendList
    {
       [Key]
        public int FriendId { get; set; }
        //imie kolegi
        public string FirstName { get; set; }
        //nazwisko kolegi
        public string LastName { get; set; }
        //nr telefonu
        public int PhoneNumber { get; set; }

        //many-many relacja
        public virtual ICollection<BorrowedItem> BorrowedItems { get; set; }
    }
}
