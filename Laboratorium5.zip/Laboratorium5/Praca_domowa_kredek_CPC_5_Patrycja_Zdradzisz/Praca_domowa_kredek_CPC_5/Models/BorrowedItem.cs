﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace Praca_domowa_kredek_CPC_5.Models
{
    
    public class BorrowedItem
    {
        //odwolanie sie do friend id
        public int FriendId { get; set; }
        //odwolanie sie do item id
        public int ItemId { get; set; }

        public virtual FriendList FriendList { get; set; }
        public virtual Item Item { get; set; }
    }
}
