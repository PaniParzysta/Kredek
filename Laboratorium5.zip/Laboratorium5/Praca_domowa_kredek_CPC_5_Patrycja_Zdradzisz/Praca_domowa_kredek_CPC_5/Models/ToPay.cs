﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Models
{
    //klasa ToPay
    public class ToPay
    {
        
        [Key]
        public int PayId { get; set; }
        //wiadomosc o wydatku
        public string PayName { get; set; }
        //nr id wydatku
        public int ExpenseId { get; set; }

        public int ExpenseForeignKey { get; set; }
        //one-one reacja
        public virtual Expense Expense { get; set; }
    }
}
