﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Models
{
    public class BorrowedContext:DbContext
    {
        public BorrowedContext(DbContextOptions<BorrowedContext> options) : base(options)
        {
            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //composite key 
            modelBuilder.Entity<BorrowedItem>()
                .HasKey(o => new { o.FriendId, o.ItemId });
            //foreign key
            modelBuilder.Entity<Expense>()
            .HasOne(b => b.ToPay)
            .WithOne(i => i.Expense)
            .HasForeignKey<ToPay>(b => b.ExpenseId);
        }

        public DbSet<Item> Item { get; set; }
        public DbSet<FriendList> FriendList { get; set; }
        public DbSet<BorrowedItem> BorrowedItem { get; set; }
        public DbSet<ToPay> ToPays { get; set; }
        public DbSet<Expense> Expenses { get; set; }
    }
}
