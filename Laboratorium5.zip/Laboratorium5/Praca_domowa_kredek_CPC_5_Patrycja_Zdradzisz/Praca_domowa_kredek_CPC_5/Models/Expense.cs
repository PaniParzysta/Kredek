﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Praca_domowa_kredek_CPC_5.Models
{
    public class Expense
    {
        [Key]
        public int Id { get; set; }

        //nazwa wydatku
        public string ExpenseName { get; set; }

        //wartość wydatku
        public int Amount { get; set; }

        //one-one relacja
        public virtual ToPay ToPay { get; set; }
    }
}
