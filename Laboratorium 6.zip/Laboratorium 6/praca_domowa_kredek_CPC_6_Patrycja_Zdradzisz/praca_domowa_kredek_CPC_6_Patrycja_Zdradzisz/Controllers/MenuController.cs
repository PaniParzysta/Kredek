﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private IMenuService _menuService;

        public MenuController(IMenuService menuService)
        {
            _menuService = menuService;
        }

        [HttpGet]
        [Produces(typeof(List<menu>))]
        public IActionResult Get()
        {
            var menuPositions = _menuService.Get();
            return Ok(menuPositions);
        }

        [HttpPost]
        [Produces(typeof(int))]
        public IActionResult Post([FromBody] menu Menu)
        {
            int id = _menuService.Post(Menu);
            return Ok(id);
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult Put([FromRoute] int id, [FromBody] menu Menu)
        {
            if (id != Menu.Id)
            {
                return Conflict("Podane Id sa różne");
            }
            else
            {
                var isUpdateSuccessfu = _menuService.Put(id, Menu);

                if (isUpdateSuccessfu)
                    return NoContent();
                else
                    return NotFound();
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete([FromRoute] int id)
        {

            var isDelete = _menuService.Delete(id);

            if (isDelete)
                return NoContent();
            else
                return NotFound();
        }
    }
}
