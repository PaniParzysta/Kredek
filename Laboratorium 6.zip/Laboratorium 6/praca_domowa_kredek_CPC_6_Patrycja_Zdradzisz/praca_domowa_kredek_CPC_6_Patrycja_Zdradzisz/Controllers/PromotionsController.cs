﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PromotionsController : ControllerBase
    {
        private IPromotionService _promotionService;

        public PromotionsController(IPromotionService promotionService)
        {
            _promotionService = promotionService;
        }

        [HttpGet]
        [Produces(typeof(List<promotions>))]
        public IActionResult Get()
        {
            var promotions = _promotionService.Get();
            return Ok(promotions);
        }

        [HttpPost]
        [Produces(typeof(int))]
        public IActionResult Post([FromBody] promotions Promotion)
        {
            int id = _promotionService.Post(Promotion);
            return Ok(id);
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult Put([FromRoute] int id, [FromBody] promotions Promotion)
        {
            if (id != Promotion.Id)
            {
                return Conflict("Podane Id sa różne");
            }
            else
            {
                var isUpdateSuccessfu = _promotionService.Put(id, Promotion);

                if (isUpdateSuccessfu)
                    return NoContent();
                else
                    return NotFound();
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete([FromRoute] int id)
        {

            var isDelete = _promotionService.Delete(id);

            if (isDelete)
                return NoContent();
            else
                return NotFound();
        }
    }
}
