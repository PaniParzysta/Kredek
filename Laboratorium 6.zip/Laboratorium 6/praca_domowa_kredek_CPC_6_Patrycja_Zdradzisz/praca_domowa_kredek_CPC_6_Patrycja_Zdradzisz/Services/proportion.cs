﻿namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services
{
    public class promotion
    {
    }
}