﻿using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services
{
    public class MenuService : IMenuService
    {
        private static List<menu> menuPositions = new List<menu>()
        {
            new menu()
            {
                Id=0,
                PositionName="spaghetti carbonara",
                Description = "makaron, boczek, jajko, ser",
                Cost = 19

            },
            new menu()
            {
                Id = 1,
                PositionName = "salatka cezara",
                Description = "kurczak, salata, warzywa sezonowe, grzanki czosnkowe",
                Cost = 34
            }
        };
        public bool Delete(int id)
        {
            var menuToDelete = menuPositions.Where(p => p.Id.Equals(id)).SingleOrDefault();
            if (menuToDelete == null)
                return false;

            menuPositions.Remove(menuToDelete);
            return true;
        }

        public List<menu> Get()
        {
            return menuPositions;
        }

        public int Post(menu Menu)
        {
            int id = 0;
            if (menuPositions.Count() == 0)
            {
                id = 0;
            }
            else
            {
                id = menuPositions.Max(x => x.Id) + 1;
            }
            Menu.Id = id;
            menuPositions.Add(Menu);

            return id;
        }

        public bool Put(int id, menu Menu)
        {
            var menuToUpdate = menuPositions.Where(p => p.Id.Equals(id)).SingleOrDefault();
            if (menuToUpdate == null)
                return false;

            menuToUpdate.PositionName = Menu.PositionName;
            menuToUpdate.Description = Menu.Description;
            menuToUpdate.Cost = Menu.Cost;

            return true;
        }
    }
}
