﻿using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services
{
    public interface IMenuService
    {
        List<menu> Get();
        int Post(menu Menu);

        bool Put(int id, menu Menu); //edit

        bool Delete(int id);
    }
}
