﻿using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services
{
    public interface IPromotionService
    {
        List<promotions> Get();
        int Post(promotions Promotion);

        bool Put(int id, promotions Promotion); //edit

        bool Delete(int id);
    }
}
