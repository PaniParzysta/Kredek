﻿using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Services
{
    public class PromotionService: IPromotionService
    {
        private static List<promotions> Promotions = new List<promotions>()
        {
            new promotions()
            {
                Id=0,
                PromotionName="wielka wyzerka",
                Description = "wszystkie pizze 25% taniej",

            },
            new promotions()
            {
                Id = 1,
                PromotionName = "wszystkie wtorki prowadza do rzymu",
                Description = "w każdy wtorek salatka cezara 50% taniej",
            }
        };
        public bool Delete(int id)
        {
            var promotionToDelete = Promotions.Where(p => p.Id.Equals(id)).SingleOrDefault();
            if (promotionToDelete == null)
                return false;

           Promotions.Remove(promotionToDelete);
            return true;
        }

        public List<promotions> Get()
        {
            return Promotions;
        }

        public int Post(promotions Promotion)
        {
            int id = 0;
            if (Promotions.Count() == 0)
            {
                id = 0;
            }
            else
            {
                id = Promotions.Max(x => x.Id) + 1;
            }
            Promotion.Id = id;
            Promotions.Add(Promotion);

            return id;
        }

        public int Post(promotion Promotion)
        {
            throw new NotImplementedException();
        }

        public bool Put(int id, promotions Promotion)
        {
            var promotionToUpdate = Promotions.Where(p => p.Id.Equals(id)).SingleOrDefault();
            if (promotionToUpdate == null)
                return false;

            promotionToUpdate.PromotionName = Promotion.PromotionName;
            promotionToUpdate.Description = Promotion.Description;

            return true;
        }
    }
}
