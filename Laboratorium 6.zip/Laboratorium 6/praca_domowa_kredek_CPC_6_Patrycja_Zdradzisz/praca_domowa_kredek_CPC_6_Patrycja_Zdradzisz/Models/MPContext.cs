﻿using Microsoft.EntityFrameworkCore;
using praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models
{
    public class MPContext: DbContext
    {
        public MPContext(DbContextOptions<MPContext> options) : base(options)
        {

        }

        public DbSet<menu> Menu { get; set; }
        public DbSet<promotions> Promotions { get; set; }
        
    }
}
