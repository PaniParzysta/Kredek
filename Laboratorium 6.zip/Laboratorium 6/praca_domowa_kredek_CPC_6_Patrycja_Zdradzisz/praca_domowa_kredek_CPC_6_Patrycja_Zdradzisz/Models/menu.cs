﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models
{
    public class menu
    {
        public int Id { get; set; }
        public string PositionName { get; set; }
        public string Description { get; set; }
        public float Cost { get; set; }
    }
}
