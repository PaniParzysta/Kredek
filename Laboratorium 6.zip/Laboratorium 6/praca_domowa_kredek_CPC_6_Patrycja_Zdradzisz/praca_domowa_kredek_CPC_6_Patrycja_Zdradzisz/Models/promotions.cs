﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_kredek_CPC_6_Patrycja_Zdradzisz.Models
{
    public class promotions
    {
        public int Id { get; set; }
        public string PromotionName { get; set; }
        public string Description { get; set; }
    }
}
