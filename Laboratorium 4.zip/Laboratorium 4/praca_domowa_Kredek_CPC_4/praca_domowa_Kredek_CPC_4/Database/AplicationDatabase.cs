﻿using Microsoft.EntityFrameworkCore;
using praca_domowa_Kredek_CPC_4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_Kredek_CPC_4.Database
{
    public class AplicationDatabase :DbContext
    {
        public AplicationDatabase(DbContextOptions<AplicationDatabase> options) : base(options)
        {
            
        }

        public DbSet<Item> Item { get; set; }
        public DbSet<Expense> Expenses { get; set; }
    }
}
