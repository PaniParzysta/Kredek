﻿using Microsoft.AspNetCore.Mvc;
using praca_domowa_Kredek_CPC_4.Database;
using praca_domowa_Kredek_CPC_4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_Kredek_CPC_4.Controllers
{
    public class ItemController : Controller
    {
        private readonly AplicationDatabase _db;

        public ItemController(AplicationDatabase db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            IEnumerable<Item> objList = _db.Item;
            ViewBag.TotalItems = objList.Count();
            return View(objList);
        }

        //GET
        public IActionResult Create()
        {

            return View();
        }

        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Item obj)
        {
            _db.Item.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
