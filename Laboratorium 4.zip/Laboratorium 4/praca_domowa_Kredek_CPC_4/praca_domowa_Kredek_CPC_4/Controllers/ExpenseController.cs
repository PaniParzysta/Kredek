﻿using Microsoft.AspNetCore.Mvc;
using praca_domowa_Kredek_CPC_4.Database;
using praca_domowa_Kredek_CPC_4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace praca_domowa_Kredek_CPC_4.Controllers
{
    public class ExpenseController : Controller
    {
       
            private readonly AplicationDatabase _db;

            public ExpenseController(AplicationDatabase db)
            {
                _db = db;
            }

            public IActionResult Index()
            {
                IEnumerable<Expense> objList = _db.Expenses;
            ViewBag.TotalExpenses = objList.Count();
            return View(objList);
            }

            //GET
            public IActionResult Create()
            {

                return View();
            }

            //POST
            [HttpPost]
            [ValidateAntiForgeryToken]
            public IActionResult Create(Expense obj)
            {
                _db.Expenses.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }

        //GET
        public IActionResult Delete(int? id)
        {
            
            var obj = _db.Expenses.Find(id);
            return View(obj);
        }

        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _db.Expenses.Find(id);
            if(obj == null)
            {
                return NotFound();
            }
            _db.Expenses.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
